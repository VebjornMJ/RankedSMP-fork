package net.lusik21556.rankedsmp.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.lusik21556.rankedsmp.RankedSMP;
import net.lusik21556.rankedsmp.gui.RankManagementGui;
import net.lusik21556.rankedsmp.inventory.InventoryManager;
import net.lusik21556.rankedsmp.item.HierarchyHammer;
import net.lusik21556.rankedsmp.rank.RankManager;
import net.minecraft.class_11560;
import net.minecraft.class_12090;
import net.minecraft.class_12099;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * Port of RankedSMPCommand.java. `/rankedsmp` and its `/rsmp` alias expose
 * the admin subcommands; `/extrainventory` and `/einv` are the player-facing
 * shortcut (unchanged from the original, which registered it as its own
 * command as well as a `/rankedsmp extrainventory` subcommand).
 */
public class RankedCommand {
	/** Equivalent of the plugin.yml permission "rankedsmp.admin" (default: op). */
	private static final class_12090 ADMIN_CHECK = new class_12090.class_12092(class_12099.field_63210);

	public static void register(RankManager rankManager, InventoryManager inventoryManager, RankManagementGui gui) {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			dispatcher.register(buildRoot("rankedsmp", rankManager, inventoryManager, gui));
			dispatcher.register(buildRoot("rsmp", rankManager, inventoryManager, gui));

			dispatcher.register(class_2170.method_9247("extrainventory")
					.executes(ctx -> openExtraInventory(ctx, inventoryManager)));
			dispatcher.register(class_2170.method_9247("einv")
					.executes(ctx -> openExtraInventory(ctx, inventoryManager)));
		});
	}

	private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> buildRoot(
			String name, RankManager rankManager, InventoryManager inventoryManager, RankManagementGui gui) {
		return class_2170.method_9247(name)
				.executes(ctx -> sendHelp(ctx))
				.then(class_2170.method_9247("help").executes(ctx -> sendHelp(ctx)))
				.then(class_2170.method_9247("start")
						.requires(class_2170.method_71774(ADMIN_CHECK))
						.executes(ctx -> {
							rankManager.startRankedSMP(ctx.getSource().method_9211());
							return 1;
						}))
				.then(class_2170.method_9247("reload")
						.requires(class_2170.method_71774(ADMIN_CHECK))
						.executes(ctx -> reload(ctx, rankManager)))
				.then(class_2170.method_9247("manage")
						.requires(class_2170.method_71774(ADMIN_CHECK))
						.executes(ctx -> openManage(ctx, gui)))
				.then(class_2170.method_9247("extrainventory")
						.requires(class_2170.method_71774(ADMIN_CHECK))
						.executes(ctx -> openExtraInventory(ctx, inventoryManager)))
				.then(class_2170.method_9247("ei")
						.requires(class_2170.method_71774(ADMIN_CHECK))
						.executes(ctx -> openExtraInventory(ctx, inventoryManager)))
				.then(class_2170.method_9247("rank")
						.requires(class_2170.method_71774(ADMIN_CHECK))
						.then(class_2170.method_9247("set")
								.then(class_2170.method_9244("player", StringArgumentType.word())
										.suggests(ONLINE_PLAYERS)
										.then(class_2170.method_9244("rank", IntegerArgumentType.integer(1, 20))
												.executes(ctx -> rankSet(ctx, rankManager)))))
						.then(class_2170.method_9247("remove")
								.then(class_2170.method_9244("player", StringArgumentType.word())
										.suggests(ONLINE_PLAYERS)
										.executes(ctx -> rankRemove(ctx, rankManager)))))
				.then(class_2170.method_9247("give")
						.requires(class_2170.method_71774(ADMIN_CHECK))
						.then(class_2170.method_9247("mace")
								.then(class_2170.method_9244("player", StringArgumentType.word())
										.suggests(ONLINE_PLAYERS)
										.executes(RankedCommand::giveMace))));
	}

	private static final SuggestionProvider<class_2168> ONLINE_PLAYERS = (ctx, builder) -> {
		String remaining = builder.getRemaining().toLowerCase();
		for (class_3222 player : ctx.getSource().method_9211().method_3760().method_14571()) {
			String name = player.method_7334().name();
			if (name.toLowerCase().startsWith(remaining)) {
				builder.suggest(name);
			}
		}
		return builder.buildFuture();
	};

	private static int sendHelp(CommandContext<class_2168> ctx) {
		class_2168 source = ctx.getSource();
		source.method_9226(() -> class_2561.method_43470("RankedSMP Commands").method_27692(class_124.field_1065), false);
		source.method_9226(() -> line("/rankedsmp help", "- Show this help menu"), false);
		source.method_9226(() -> line("/rankedsmp start", "- Start ranked mode and assign ranks"), false);
		source.method_9226(() -> line("/rankedsmp reload", "- Reload configuration"), false);
		source.method_9226(() -> line("/rankedsmp manage", "- Open rank management GUI"), false);
		source.method_9226(() -> line("/rankedsmp rank set <player> <rank>", "- Set a player's rank"), false);
		source.method_9226(() -> line("/rankedsmp rank remove <player>", "- Remove a player's rank"), false);
		source.method_9226(() -> line("/rankedsmp give mace <player>", "- Give Hierarchy Hammer to a player"), false);
		source.method_9226(() -> line("/rankedsmp extrainventory", "- Open your extra inventory"), false);
		return 1;
	}

	private static class_2561 line(String command, String description) {
		return class_2561.method_43470(command + " ").method_27692(class_124.field_1075).method_10852(class_2561.method_43470(description).method_27692(class_124.field_1080));
	}

	private static int reload(CommandContext<class_2168> ctx, RankManager rankManager) {
		class_2168 source = ctx.getSource();
		MinecraftServer server = source.method_9211();
		RankedSMP mod = RankedSMP.getInstance();
		mod.reloadConfig();
		source.method_9226(() -> class_2561.method_43470("Configuration reloaded successfully!").method_27692(class_124.field_1060), false);
		rankManager.refreshAllOnlinePlayers(server);
		int count = server.method_3760().method_14571().size();
		source.method_9226(() -> class_2561.method_43470("Updated " + count + " online players.").method_27692(class_124.field_1054), false);
		return 1;
	}

	private static int openManage(CommandContext<class_2168> ctx, RankManagementGui gui) {
		class_3222 player = ctx.getSource().method_44023();
		if (player == null) {
			ctx.getSource().method_9213(class_2561.method_43470("Only players can use this command!").method_27692(class_124.field_1061));
			return 0;
		}
		gui.openGui(player);
		return 1;
	}

	private static int openExtraInventory(CommandContext<class_2168> ctx, InventoryManager inventoryManager) {
		class_3222 player = ctx.getSource().method_44023();
		if (player == null) {
			ctx.getSource().method_9213(class_2561.method_43470("Only players can use this command!").method_27692(class_124.field_1061));
			return 0;
		}
		inventoryManager.openExtraInventory(player);
		return 1;
	}

	private static int rankSet(CommandContext<class_2168> ctx, RankManager rankManager) {
		class_2168 source = ctx.getSource();
		MinecraftServer server = source.method_9211();
		String name = StringArgumentType.getString(ctx, "player");
		int rank = IntegerArgumentType.getInteger(ctx, "rank");

		ResolvedPlayer target = resolvePlayer(server, name);
		if (target == null) {
			source.method_9213(class_2561.method_43470("Player not found!").method_27692(class_124.field_1061));
			return 0;
		}

		UUID currentHolder = rankManager.getPlayerWithRank(server, rank);
		if (currentHolder != null && !currentHolder.equals(target.uuid())) {
			String holderName = resolveName(server, currentHolder);
			source.method_9213(class_2561.method_43470("Rank #" + rank + " is already taken by " + holderName + "!").method_27692(class_124.field_1061));
			return 0;
		}

		if (target.online() != null) {
			rankManager.setPlayerRank(target.online(), rank);
			target.online().method_7353(class_2561.method_43470("Your rank has been set to ")
					.method_27692(class_124.field_1060)
					.method_10852(class_2561.method_43470("#" + rank).method_27692(class_124.field_1054))
					.method_10852(class_2561.method_43470("!").method_27692(class_124.field_1060)), false);
		} else {
			rankManager.setOfflineRank(server, target.uuid(), rank);
		}
		source.method_9226(() -> class_2561.method_43470("Set " + target.name() + "'s rank to #" + rank).method_27692(class_124.field_1060), false);
		return 1;
	}

	private static int rankRemove(CommandContext<class_2168> ctx, RankManager rankManager) {
		class_2168 source = ctx.getSource();
		MinecraftServer server = source.method_9211();
		String name = StringArgumentType.getString(ctx, "player");

		ResolvedPlayer target = resolvePlayer(server, name);
		if (target == null) {
			source.method_9213(class_2561.method_43470("Player not found!").method_27692(class_124.field_1061));
			return 0;
		}

		if (target.online() != null) {
			rankManager.removePlayerRank(target.online());
			target.online().method_7353(class_2561.method_43470("Your rank has been removed!").method_27692(class_124.field_1054), false);
		} else {
			rankManager.removeOfflineRank(server, target.uuid());
		}
		source.method_9226(() -> class_2561.method_43470("Removed " + target.name() + "'s rank!").method_27692(class_124.field_1060), false);
		return 1;
	}

	private static int giveMace(CommandContext<class_2168> ctx) {
		class_2168 source = ctx.getSource();
		String name = StringArgumentType.getString(ctx, "player");
		class_3222 target = source.method_9211().method_3760().method_14566(name);
		if (target == null) {
			source.method_9213(class_2561.method_43470("Player not found!").method_27692(class_124.field_1061));
			return 0;
		}
		class_1799 mace = HierarchyHammer.create();
		target.method_31548().method_7394(mace);
		if (!mace.method_7960()) {
			target.method_7328(mace, false);
		}
		target.method_7353(class_2561.method_43470("You received the Hierarchy Hammer!").method_27692(class_124.field_1060), false);
		source.method_9226(() -> class_2561.method_43470("Gave Hierarchy Hammer to " + target.method_7334().name()).method_27692(class_124.field_1060), false);
		return 1;
	}

	private static ResolvedPlayer resolvePlayer(MinecraftServer server, String name) {
		class_3222 online = server.method_3760().method_14566(name);
		if (online != null) {
			return new ResolvedPlayer(online.method_5667(), online.method_7334().name(), online);
		}
		return server.method_73550().comp_4407().method_14515(name)
				.map(entry -> new ResolvedPlayer(entry.comp_4422(), entry.comp_4423(), null))
				.orElse(null);
	}

	private static String resolveName(MinecraftServer server, UUID uuid) {
		class_3222 online = server.method_3760().method_14602(uuid);
		if (online != null) {
			return online.method_7334().name();
		}
		return server.method_73550().comp_4407().method_14512(uuid)
				.map(class_11560::comp_4423)
				.orElse(uuid.toString());
	}

	private record ResolvedPlayer(UUID uuid, String name, class_3222 online) {
	}
}
