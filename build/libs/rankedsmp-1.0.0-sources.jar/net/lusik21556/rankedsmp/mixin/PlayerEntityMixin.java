package net.lusik21556.rankedsmp.mixin;

import net.lusik21556.rankedsmp.RankedSMP;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Port of XPListener.java's XP multiplier. Bukkit exposed a cancellable
 * PlayerExpChangeEvent for this; vanilla/Fabric has no equivalent event, so
 * the multiplier is applied at the source via a mixin into
 * {@link class_1657#method_7255(int)}.
 */
@Mixin(class_1657.class)
public abstract class PlayerEntityMixin {
	@ModifyVariable(method = "addExperience", at = @At("HEAD"), argsOnly = true)
	private int rankedsmp$multiplyExperience(int amount) {
		RankedSMP mod = RankedSMP.getInstance();
		if (mod == null) {
			return amount;
		}
		class_1657 self = (class_1657) (Object) this;
		if (self instanceof class_3222 player) {
			return (int) (amount * mod.getRankManager().getXPMultiplier(player));
		}
		return amount;
	}
}
