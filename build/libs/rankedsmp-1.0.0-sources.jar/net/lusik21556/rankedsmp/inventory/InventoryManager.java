package net.lusik21556.rankedsmp.inventory;

import net.lusik21556.rankedsmp.data.RankedSaveData;
import net.lusik21556.rankedsmp.gui.ExtraInventoryScreenHandler;
import net.lusik21556.rankedsmp.rank.RankManager;
import net.minecraft.class_124;
import net.minecraft.class_1264;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_747;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Port of InventoryManager.java. Ranks 1-10 unlock a personal "extra
 * inventory" (54 slots down to 15) rendered as a vanilla chest GUI so no
 * client-side mod is required. Contents are persisted in {@link RankedSaveData}.
 *
 * Unlike the original SQLite-backed plugin, storage here is an in-memory map
 * backed by the world's persistent state, so loads are synchronous - there's
 * no async round trip left to guard against.
 */
public class InventoryManager {
	private static final long COOLDOWN_MS = 3000L;

	private final RankManager rankManager;
	private final Map<UUID, class_1277> extraInventories = new HashMap<>();
	private final Map<UUID, Long> cooldowns = new HashMap<>();

	public InventoryManager(RankManager rankManager) {
		this.rankManager = rankManager;
	}

	private int calculateInventorySize(int slots) {
		if (slots <= 0) {
			return 9;
		}
		return ((slots - 1) / 9 + 1) * 9;
	}

	public void openExtraInventory(class_3222 player) {
		int rank = rankManager.getPlayerRank(player);
		if (!rankManager.hasExtraInventoryAccess(rank)) {
			player.method_7353(class_2561.method_43470("You don't have access to extra inventory! (Requires Rank 10 or better)").method_27692(class_124.field_1061), false);
			return;
		}

		UUID uuid = player.method_5667();
		long now = System.currentTimeMillis();
		long last = cooldowns.getOrDefault(uuid, 0L);
		long elapsed = now - last;
		if (elapsed < COOLDOWN_MS) {
			long remaining = (COOLDOWN_MS - elapsed + 999L) / 1000L;
			player.method_7353(class_2561.method_43470("Please wait " + remaining + "s before opening your extra inventory again.").method_27692(class_124.field_1061), false);
			return;
		}
		cooldowns.put(uuid, now);

		int slots = rankManager.getExtraInventorySlots(player);
		int requiredSize = calculateInventorySize(slots);
		class_1277 inv = getOrLoadInventory(player, slots);
		if (inv.method_5439() != requiredSize) {
			inv = rebuild(inv, requiredSize, slots);
			extraInventories.put(uuid, inv);
		}
		openScreen(player, inv, slots);
	}

	/** Called shortly after join to warm the cache so the GUI opens instantly later. */
	public void loadPlayerInventory(class_3222 player) {
		int rank = rankManager.getPlayerRank(player);
		if (!rankManager.hasExtraInventoryAccess(rank)) {
			return;
		}
		getOrLoadInventory(player, rankManager.getExtraInventorySlots(player));
	}

	private class_1277 getOrLoadInventory(class_3222 player, int slots) {
		UUID uuid = player.method_5667();
		class_1277 inv = extraInventories.get(uuid);
		if (inv != null) {
			return inv;
		}
		RankedSaveData.StoredInventory stored = RankedSaveData.get(player.method_51469().method_8503()).getInventory(uuid);
		class_1277 fresh = new class_1277(calculateInventorySize(slots));
		applyStored(fresh, stored, slots);
		extraInventories.put(uuid, fresh);
		return fresh;
	}

	private void applyStored(class_1277 inv, RankedSaveData.StoredInventory stored, int usableSlots) {
		if (stored != null) {
			for (RankedSaveData.SlotEntry entry : stored.items()) {
				if (entry.slot() >= 0 && entry.slot() < inv.method_5439()) {
					inv.method_5447(entry.slot(), entry.item().method_7972());
				}
			}
		}
		fillBarriers(inv, usableSlots);
	}

	private class_1277 rebuild(class_1277 old, int newSize, int usableSlots) {
		class_1277 fresh = new class_1277(newSize);
		for (int i = 0; i < Math.min(usableSlots, old.method_5439()); i++) {
			class_1799 item = old.method_5438(i);
			if (!item.method_7960() && !item.method_31574(class_1802.field_8077)) {
				fresh.method_5447(i, item.method_7972());
			}
		}
		fillBarriers(fresh, usableSlots);
		return fresh;
	}

	private void fillBarriers(class_1277 inv, int usableSlots) {
		class_1799 barrier = new class_1799(class_1802.field_8077);
		barrier.method_57379(class_9334.field_49631, class_2561.method_43470("Locked Slot").method_27692(class_124.field_1061));
		barrier.method_57379(class_9334.field_49632, new class_9290(List.of(class_2561.method_43470("Upgrade your rank for more slots!").method_27692(class_124.field_1080))));
		for (int i = Math.max(usableSlots, 0); i < inv.method_5439(); i++) {
			inv.method_5447(i, barrier.method_7972());
		}
	}

	private void openScreen(class_3222 player, class_1277 inv, int usableSlots) {
		int rows = inv.method_5439() / 9;
		player.method_17355(new class_747(
				(syncId, playerInv, p) -> new ExtraInventoryScreenHandler(syncId, playerInv, inv, rows, usableSlots, () -> onScreenClosed(player)),
				class_2561.method_43470("Extra Inventory").method_27692(class_124.field_1065)
		));
	}

	private void onScreenClosed(class_3222 player) {
		int rank = rankManager.getPlayerRank(player);
		if (!rankManager.hasExtraInventoryAccess(rank)) {
			removeExtraInventory(player);
		} else {
			saveExtraInventory(player);
		}
	}

	public boolean isExtraInventory(net.minecraft.class_1263 inv) {
		return extraInventories.containsValue(inv);
	}

	public boolean hasLoadedExtraInventory(UUID uuid) {
		return extraInventories.containsKey(uuid);
	}

	public boolean hasLoadedExtraInventory(class_3222 player) {
		return hasLoadedExtraInventory(player.method_5667());
	}

	public void saveExtraInventory(class_3222 player) {
		class_1277 inv = extraInventories.get(player.method_5667());
		if (inv != null) {
			int slots = rankManager.getExtraInventorySlots(player);
			persist(player.method_51469().method_8503(), player.method_5667(), inv, slots);
		}
	}

	public void saveAllInventories(MinecraftServer server) {
		for (Map.Entry<UUID, class_1277> entry : extraInventories.entrySet()) {
			class_3222 player = server.method_3760().method_14602(entry.getKey());
			int slots = player != null ? rankManager.getExtraInventorySlots(player) : entry.getValue().method_5439();
			persist(server, entry.getKey(), entry.getValue(), slots);
		}
	}

	private void persist(MinecraftServer server, UUID uuid, class_1277 inv, int slots) {
		List<RankedSaveData.SlotEntry> entries = new ArrayList<>();
		for (int i = 0; i < Math.min(slots, inv.method_5439()); i++) {
			class_1799 item = inv.method_5438(i);
			if (!item.method_7960() && !item.method_31574(class_1802.field_8077)) {
				entries.add(new RankedSaveData.SlotEntry(i, item.method_7972()));
			}
		}
		RankedSaveData.get(server).setInventory(uuid, new RankedSaveData.StoredInventory(slots, entries));
	}

	public void clearExtraInventory(class_3222 player) {
		class_1277 inv = extraInventories.get(player.method_5667());
		if (inv != null) {
			for (int i = 0; i < inv.method_5439(); i++) {
				class_1799 item = inv.method_5438(i);
				if (!item.method_7960() && !item.method_31574(class_1802.field_8077)) {
					class_1264.method_5449(player.method_51469(), player.method_23317(), player.method_23318(), player.method_23321(), item);
				}
			}
			inv.method_5448();
		}
		RankedSaveData.get(player.method_51469().method_8503()).removeInventory(player.method_5667());
	}

	public void removeExtraInventory(class_3222 player) {
		clearExtraInventory(player);
		extraInventories.remove(player.method_5667());
	}

	/** Drops items beyond the new (smaller) rank's slot count when a player wasn't online to see it happen live. */
	public void handleDeathDropsFallback(class_3222 player, class_3218 deathWorld, class_243 deathPos, int newRank) {
		if (extraInventories.containsKey(player.method_5667())) {
			return;
		}
		int newSlots = rankManager.getSlotsForRank(newRank);
		RankedSaveData data = RankedSaveData.get(player.method_51469().method_8503());
		RankedSaveData.StoredInventory stored = data.getInventory(player.method_5667());
		if (stored == null) {
			return;
		}
		List<RankedSaveData.SlotEntry> kept = new ArrayList<>();
		for (RankedSaveData.SlotEntry entry : stored.items()) {
			if (entry.slot() >= newSlots) {
				class_1264.method_5449(deathWorld, deathPos.field_1352, deathPos.field_1351, deathPos.field_1350, entry.item().method_7972());
			} else {
				kept.add(entry);
			}
		}
		if (newSlots <= 0) {
			data.removeInventory(player.method_5667());
		} else {
			data.setInventory(player.method_5667(), new RankedSaveData.StoredInventory(newSlots, kept));
		}
	}

	public void unloadPlayer(class_3222 player) {
		saveExtraInventory(player);
		extraInventories.remove(player.method_5667());
		cooldowns.remove(player.method_5667());
	}

	public void updateExtraInventory(class_3222 player, int oldRank, int newRank) {
		boolean hadAccess = rankManager.hasExtraInventoryAccess(oldRank);
		boolean hasAccess = rankManager.hasExtraInventoryAccess(newRank);

		if (hadAccess && !hasAccess) {
			player.method_7353(class_2561.method_43470("You lost access to extra inventory! Items dropped.").method_27692(class_124.field_1061), false);
			removeExtraInventory(player);
		} else if (hadAccess) {
			int oldSlots = rankManager.getSlotsForRank(oldRank);
			int newSlots = rankManager.getSlotsForRank(newRank);
			if (newSlots < oldSlots) {
				resizeInventory(player, newSlots);
				player.method_7353(class_2561.method_43470("Your extra inventory was resized to " + newSlots + " slots.").method_27692(class_124.field_1054), false);
			} else if (newSlots > oldSlots) {
				resizeInventory(player, newSlots);
				player.method_7353(class_2561.method_43470("Your extra inventory expanded to " + newSlots + " slots!").method_27692(class_124.field_1060), false);
			}
		} else if (hasAccess) {
			player.method_7353(class_2561.method_43470("You gained access to extra inventory! Use /extrainventory").method_27692(class_124.field_1060), false);
		}
	}

	private void resizeInventory(class_3222 player, int newSlots) {
		class_1277 oldInv = extraInventories.get(player.method_5667());
		if (oldInv == null) {
			return;
		}
		boolean wasOpen = player.field_7512 instanceof ExtraInventoryScreenHandler handler
				&& handler.backingInventory() == oldInv;

		int newSize = calculateInventorySize(newSlots);
		class_1277 newInv = new class_1277(newSize);
		for (int i = 0; i < Math.min(newSlots, oldInv.method_5439()); i++) {
			class_1799 item = oldInv.method_5438(i);
			if (!item.method_7960() && !item.method_31574(class_1802.field_8077)) {
				newInv.method_5447(i, item.method_7972());
			}
		}
		for (int i = newSlots; i < oldInv.method_5439(); i++) {
			class_1799 item = oldInv.method_5438(i);
			if (!item.method_7960() && !item.method_31574(class_1802.field_8077)) {
				class_1264.method_5449(player.method_51469(), player.method_23317(), player.method_23318(), player.method_23321(), item);
			}
		}
		fillBarriers(newInv, newSlots);
		extraInventories.put(player.method_5667(), newInv);
		saveExtraInventory(player);
		if (wasOpen) {
			openScreen(player, newInv, newSlots);
		}
	}
}
