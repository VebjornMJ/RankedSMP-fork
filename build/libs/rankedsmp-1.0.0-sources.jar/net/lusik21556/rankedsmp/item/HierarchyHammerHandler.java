package net.lusik21556.rankedsmp.item;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.lusik21556.rankedsmp.util.Scheduler;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Port of HierarchyHammerListener.java: the HierArchy Hammer's "SENTENCING"
 * dash and "VERDICT" combo finisher. Right-click launches the wielder
 * forward and starts a particle trail; landing consecutive falling
 * mace-smash hits within the window builds a combo, and the 4th hit
 * unleashes an execution (levitate, hold, then a burst of damage/particles)
 * instead of dealing its normal hit.
 */
public class HierarchyHammerHandler {
	private static final double DASH_SPEED = 2.2;
	private static final double DASH_UP = 0.75;
	private static final long MISS_COOLDOWN_MS = 10_000L;
	private static final long VERDICT_COOLDOWN_MS = 30_000L;

	private final Scheduler scheduler;

	private final Map<UUID, Long> dashCooldowns = new HashMap<>();
	private final Map<UUID, Integer> hitCounter = new HashMap<>();
	private final Set<UUID> sentencingActive = new HashSet<>();
	private final Map<UUID, Long> sentencingStartTime = new HashMap<>();
	private final Map<UUID, Integer> dashCharges = new HashMap<>();
	private final Map<UUID, Long> lastHitTime = new HashMap<>();
	private final Set<UUID> missScheduled = new HashSet<>();
	private final Map<UUID, TrailState> activeTrails = new HashMap<>();

	public HierarchyHammerHandler(Scheduler scheduler) {
		this.scheduler = scheduler;
	}

	public void register() {
		UseItemCallback.EVENT.register(this::onUseItem);
		AttackEntityCallback.EVENT.register(this::onAttackEntity);
		ServerPlayerEvents.LEAVE.register(player -> resetAll(player.method_5667()));
		net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(this::checkMisses);
	}

	private class_1269 onUseItem(net.minecraft.class_1657 playerEntity, class_1937 world, class_1268 hand) {
		if (!(playerEntity instanceof class_3222 player) || world.method_8608()) {
			return class_1269.field_5811;
		}
		class_1799 item = player.method_5998(hand);
		if (!HierarchyHammer.isHierarchyHammer(item)) {
			return class_1269.field_5811;
		}

		UUID uuid = player.method_5667();
		long now = System.currentTimeMillis();
		Long cooldownUntil = dashCooldowns.get(uuid);
		if (cooldownUntil != null && now < cooldownUntil) {
			return class_1269.field_5811;
		}

		if (sentencingActive.contains(uuid)) {
			int charges = dashCharges.getOrDefault(uuid, 0);
			if (charges <= 0) {
				return class_1269.field_5811;
			}
			dashCharges.put(uuid, charges - 1);
			performMiniDash(player);
			return class_1269.field_5812;
		}

		sentencingActive.add(uuid);
		sentencingStartTime.put(uuid, now);
		lastHitTime.put(uuid, now);
		hitCounter.put(uuid, 0);
		dashCharges.put(uuid, 0);

		class_3218 serverWorld = (class_3218) world;
		serverWorld.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_47725, class_3419.field_15248, 0.75f, 0.7f);
		class_243 direction = player.method_5720();
		player.method_18799(direction.method_1021(DASH_SPEED).method_1031(0, DASH_UP - direction.field_1351 * DASH_SPEED, 0));
		player.field_64356 = true;
		startDashTrail(player);
		return class_1269.field_5812;
	}

	private class_1269 onAttackEntity(net.minecraft.class_1657 playerEntity, class_1937 world, class_1268 hand, class_1297 entity, net.minecraft.class_3966 hitResult) {
		if (!(playerEntity instanceof class_3222 attacker) || world.method_8608()) {
			return class_1269.field_5811;
		}
		if (!(entity instanceof class_3222 victim)) {
			return class_1269.field_5811;
		}
		class_1799 item = attacker.method_5998(hand);
		if (!HierarchyHammer.isHierarchyHammer(item)) {
			return class_1269.field_5811;
		}
		UUID uuid = attacker.method_5667();
		if (!sentencingActive.contains(uuid)) {
			return class_1269.field_5811;
		}
		if (!(attacker.field_6017 > 1.5)) {
			return class_1269.field_5811;
		}

		int hits = hitCounter.getOrDefault(uuid, 0) + 1;
		hitCounter.put(uuid, hits);
		lastHitTime.put(uuid, System.currentTimeMillis());

		if (hits < 4) {
			dashCharges.merge(uuid, 1, Integer::sum);
			class_3218 serverWorld = (class_3218) world;
			serverWorld.method_43128(null, attacker.method_23317(), attacker.method_23318(), attacker.method_23321(), class_3417.field_14833, class_3419.field_15248, 0.5f, 1.0f);
			attacker.method_7353(class_2561.method_43470(hits + " / 3").method_27692(net.minecraft.class_124.field_1065), true);
			return class_1269.field_5811;
		}

		executeVerdict(attacker, victim);
		resetSentencing(uuid);
		dashCooldowns.put(uuid, System.currentTimeMillis() + VERDICT_COOLDOWN_MS);
		attacker.method_7357().method_62835(item, 600);
		return class_1269.field_5814;
	}

	private void performMiniDash(class_3222 player) {
		lastHitTime.put(player.method_5667(), System.currentTimeMillis());
		class_3218 world = (class_3218) player.method_51469();
		class_243 pos = player.method_73189();
		world.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_47725, class_3419.field_15248, 0.75f, 0.7f);
		class_243 direction = player.method_5720();
		player.method_18799(direction.method_1021(DASH_SPEED).method_1031(0, DASH_UP - direction.field_1351 * DASH_SPEED, 0));
		player.field_64356 = true;
		spawnRotatingCircle(world, pos.method_1031(0, 0.1, 0), 0.0);
		startDashTrail(player);
	}

	private void resetSentencing(UUID uuid) {
		sentencingActive.remove(uuid);
		hitCounter.remove(uuid);
		sentencingStartTime.remove(uuid);
		dashCharges.remove(uuid);
		lastHitTime.remove(uuid);
		activeTrails.remove(uuid);
	}

	private void resetAll(UUID uuid) {
		dashCooldowns.remove(uuid);
		missScheduled.remove(uuid);
		resetSentencing(uuid);
	}

	private void checkMisses(MinecraftServer server) {
		if (sentencingActive.isEmpty()) {
			return;
		}
		for (UUID uuid : new ArrayList<>(sentencingActive)) {
			class_3222 player = server.method_3760().method_14602(uuid);
			if (player == null) {
				resetSentencing(uuid);
				continue;
			}
			if (!player.method_24828()) {
				continue;
			}
			long now = System.currentTimeMillis();
			if (now - sentencingStartTime.getOrDefault(uuid, now) < 1000L) {
				continue;
			}
			if (now - lastHitTime.getOrDefault(uuid, 0L) < 1000L) {
				continue;
			}
			if (missScheduled.contains(uuid)) {
				continue;
			}
			missScheduled.add(uuid);
			scheduler.runLater(10, () -> {
				missScheduled.remove(uuid);
				if (!sentencingActive.contains(uuid)) {
					return;
				}
				class_3222 p = server.method_3760().method_14602(uuid);
				if (p == null || !p.method_24828()) {
					return;
				}
				if (System.currentTimeMillis() - lastHitTime.getOrDefault(uuid, 0L) < 1000L) {
					return;
				}
				if (hitCounter.getOrDefault(uuid, 0) >= 4) {
					return;
				}
				applyMissCooldown(p);
			});
		}
	}

	private void applyMissCooldown(class_3222 player) {
		UUID uuid = player.method_5667();
		dashCooldowns.put(uuid, System.currentTimeMillis() + MISS_COOLDOWN_MS);
		resetSentencing(uuid);
		class_3218 world = (class_3218) player.method_51469();
		world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), class_3417.field_14833, class_3419.field_15248, 0.5f, 1.1f);
		player.method_7353(class_2561.method_43470("You missed, now on cooldown for 10s").method_27692(net.minecraft.class_124.field_1065), true);
		class_1799 held = player.method_6047();
		if (HierarchyHammer.isHierarchyHammer(held)) {
			player.method_7357().method_62835(held, 200);
		}
	}

	private void executeVerdict(class_3222 attacker, class_3222 victim) {
		class_3218 world = victim.method_51469();
		double damage = 40.0;
		class_1293 resistance = victim.method_6112(class_1294.field_5907);
		if (resistance != null) {
			damage = Math.max(0.0, damage * (1.0 - (resistance.method_5578() + 1) * 0.2));
		}
		double finalDamage = damage;

		victim.method_6092(new class_1293(class_1294.field_5902, 60, 0, false, false));

		scheduler.runLater(60, () -> {
			if (!victim.method_5805()) {
				return;
			}
			victim.method_6016(class_1294.field_5902);
			victim.method_5875(true);
			victim.method_18799(class_243.field_1353);
			victim.field_64356 = true;

			class_243 pos = victim.method_73189();
			class_3218 raisedWorld = victim.method_51469();
			raisedWorld.method_65096(class_2398.field_11221, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
			raisedWorld.method_65096(class_2398.field_49140, pos.field_1352, pos.field_1351, pos.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
			raisedWorld.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14833, class_3419.field_15248, 0.5f, 1.0f);
			raisedWorld.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_15024, class_3419.field_15248, 0.2f, 1.0f);

			for (int j = 0; j < 48; j++) {
				double phi = Math.acos(1.0 - 2.0 * (j + 0.5) / 48.0);
				double theta = Math.PI * (1.0 + Math.sqrt(5.0)) * j;
				double dx = Math.sin(phi) * Math.cos(theta);
				double dy = Math.cos(phi);
				double dz = Math.sin(phi) * Math.sin(theta);
				raisedWorld.method_65096(class_2398.field_29644, pos.field_1352, pos.field_1351, pos.field_1350, 0, dx, dy, dz, 0.6);
			}

			victim.field_6008 = 0;
			victim.method_64397(raisedWorld, raisedWorld.method_48963().method_48802(attacker), (float) finalDamage);

			for (int i = 0; i < 36; i++) {
				double angle = Math.PI * 2 * i / 36.0;
				raisedWorld.method_65096(class_2398.field_47493, pos.field_1352 + 2.0 * Math.cos(angle), pos.field_1351, pos.field_1350 + 2.0 * Math.sin(angle), 1, 0.0, 0.0, 0.0, 0.0);
			}

			if (victim.method_5805()) {
				victim.method_5875(false);
			}
		});
	}

	private void startDashTrail(class_3222 player) {
		TrailState state = new TrailState();
		activeTrails.put(player.method_5667(), state);
		tickTrail(player, state);
	}

	private void tickTrail(class_3222 player, TrailState state) {
		if (activeTrails.get(player.method_5667()) != state) {
			return;
		}
		if (!player.method_5805()) {
			activeTrails.remove(player.method_5667());
			return;
		}
		if (player.method_24828() && state.ticks > 5) {
			activeTrails.remove(player.method_5667());
			return;
		}

		class_3218 world = player.method_51469();
		class_243 current = player.method_73189();
		world.method_65096(new class_2390(packRgb(242, 188, 69), 1.2f), current.field_1352, current.field_1351 + 1.0, current.field_1350, 3, 0.2, 0.2, 0.2, 0.0);

		if (state.ticks % 3 == 0 && state.circleCount < 4) {
			state.lastCircleLocation = current;
			state.circleCount++;
			spawnRotatingCircle(world, state.lastCircleLocation, state.angle);
		}
		if (state.lastCircleLocation != null && state.lastCircleLocation.method_1022(current) < 3.0) {
			spawnRotatingCircle(world, state.lastCircleLocation, state.angle);
		}

		state.angle += 0.19634954084936207;
		state.ticks++;
		scheduler.runLater(1, () -> tickTrail(player, state));
	}

	private void spawnRotatingCircle(class_3218 world, class_243 center, double angle) {
		class_2390 dust = new class_2390(packRgb(242, 188, 69), 1.0f);
		for (int i = 0; i < 16; i++) {
			double offsetAngle = angle + i * Math.PI / 8.0;
			world.method_65096(dust,
					center.field_1352 + Math.cos(offsetAngle) * 0.8, center.field_1351 + 0.1, center.field_1350 + Math.sin(offsetAngle) * 0.8,
					1, 0.0, 0.0, 0.0, 0.0);
		}
	}

	private static int packRgb(int r, int g, int b) {
		return (r << 16) | (g << 8) | b;
	}

	private static final class TrailState {
		int ticks = 0;
		double angle = 0.0;
		int circleCount = 0;
		class_243 lastCircleLocation = null;
	}
}
