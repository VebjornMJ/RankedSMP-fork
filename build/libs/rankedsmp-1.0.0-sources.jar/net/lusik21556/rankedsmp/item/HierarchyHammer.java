package net.lusik21556.rankedsmp.item;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9280;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

/**
 * Port of items/HierarchyHammer.java. It's a plain vanilla Mace marked with a
 * bit of custom NBT data plus custom model data (for a resource pack to hook
 * into, same as the original relied on a texture pack for its look) so the
 * combat handler can recognise it without adding a new Item type - meaning no
 * client-side mod is required to hold or swing it.
 */
public final class HierarchyHammer {
	private static final String MARKER_KEY = "hierarchy_hammer";
	private static final float CUSTOM_MODEL_DATA = 543.0f;

	private HierarchyHammer() {
	}

	public static class_1799 create() {
		class_1799 item = new class_1799(class_1802.field_49814);

		item.method_57379(class_9334.field_49631, class_2561.method_43470("HIERARCHY MACE").method_27695(class_124.field_1065, class_124.field_1067));

		List<class_2561> lore = new ArrayList<>();
		lore.add(class_2561.method_43470("A powerful hammer that manifested").method_27695(class_124.field_1063, class_124.field_1056));
		lore.add(class_2561.method_43470("as a result of improper judgement.").method_27695(class_124.field_1063, class_124.field_1056));
		lore.add(class_2561.method_43470(""));
		lore.add(class_2561.method_43470("SENTENCING ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("RMB").method_27692(class_124.field_1068)));
		lore.add(class_2561.method_43470("Launch forward, allowing you to initiate").method_27692(class_124.field_1080));
		lore.add(class_2561.method_43470("hits with the weapon. This dash will stop").method_27692(class_124.field_1080));
		lore.add(class_2561.method_43470("Missing an attack will put it on cooldown.").method_27692(class_124.field_1080));
		lore.add(class_2561.method_43470(""));
		lore.add(class_2561.method_43470("VERDICT").method_27692(class_124.field_1065));
		lore.add(class_2561.method_43470("After hitting 4 consecutive smash hits without").method_27692(class_124.field_1080));
		lore.add(class_2561.method_43470("missing, your next hit executes the verdict.").method_27692(class_124.field_1080));
		item.method_57379(class_9334.field_49632, new class_9290(lore));

		item.method_57379(class_9334.field_49637, new class_9280(
				List.of(CUSTOM_MODEL_DATA), List.of(), List.of(), List.of()));

		class_2487 marker = new class_2487();
		marker.method_10556(MARKER_KEY, true);
		class_9279.method_57453(class_9334.field_49628, item, marker);

		return item;
	}

	public static boolean isHierarchyHammer(class_1799 item) {
		if (item == null || !item.method_31574(class_1802.field_49814)) {
			return false;
		}
		return item.method_58695(class_9334.field_49628, class_9279.field_49302)
				.method_57461().method_68566(MARKER_KEY, false);
	}

}
