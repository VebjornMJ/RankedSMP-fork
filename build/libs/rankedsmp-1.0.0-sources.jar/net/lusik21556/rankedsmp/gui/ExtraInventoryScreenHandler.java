package net.lusik21556.rankedsmp.gui;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

/**
 * A vanilla-rendered chest-like inventory (no client mod required) that gives
 * a player extra storage slots. Slots beyond {@code usableSlots} are locked:
 * they display a "Locked Slot" barrier placed by {@link net.lusik21556.rankedsmp.inventory.InventoryManager}
 * and reject both insertion and extraction, mirroring the original plugin's
 * barrier-filled slots.
 */
public class ExtraInventoryScreenHandler extends class_1703 {
	private final class_1263 inventory;
	private final int rows;
	private final int usableSlots;
	private final Runnable onClose;

	public ExtraInventoryScreenHandler(int syncId, class_1661 playerInventory, class_1263 inventory, int rows, int usableSlots, Runnable onClose) {
		super(typeForRows(rows), syncId);
		method_17359(inventory, rows * 9);
		this.inventory = inventory;
		this.rows = rows;
		this.usableSlots = usableSlots;
		this.onClose = onClose;
		inventory.method_5435(playerInventory.field_7546);

		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < 9; col++) {
				int index = col + row * 9;
				method_7621(new LockableSlot(inventory, index, 8 + col * 18, 18 + row * 18, index < usableSlots));
			}
		}
		method_61624(playerInventory, 8, 18 + rows * 18 + 13);
	}

	private static class_3917<?> typeForRows(int rows) {
		return switch (rows) {
			case 1 -> class_3917.field_18664;
			case 2 -> class_3917.field_18665;
			case 3 -> class_3917.field_17326;
			case 4 -> class_3917.field_18666;
			case 5 -> class_3917.field_18667;
			default -> class_3917.field_17327;
		};
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return inventory.method_5443(player);
	}

	@Override
	public class_1799 method_7601(class_1657 player, int slotIndex) {
		class_1799 result = class_1799.field_8037;
		class_1735 slot = field_7761.get(slotIndex);
		if (slot != null && slot.method_7681()) {
			class_1799 stack = slot.method_7677();
			result = stack.method_7972();
			if (slotIndex < rows * 9) {
				if (!method_7616(stack, rows * 9, field_7761.size(), true)) {
					return class_1799.field_8037;
				}
			} else {
				if (!method_7616(stack, 0, usableSlots, false)) {
					return class_1799.field_8037;
				}
			}
			if (stack.method_7960()) {
				slot.method_53512(class_1799.field_8037);
			} else {
				slot.method_7668();
			}
		}
		return result;
	}

	@Override
	public void method_7595(class_1657 player) {
		super.method_7595(player);
		inventory.method_5432(player);
		onClose.run();
	}

	public class_1263 backingInventory() {
		return inventory;
	}

	private static class LockableSlot extends class_1735 {
		private final boolean usable;

		LockableSlot(class_1263 inventory, int index, int x, int y, boolean usable) {
			super(inventory, index, x, y);
			this.usable = usable;
		}

		@Override
		public boolean method_7680(class_1799 stack) {
			return usable;
		}

		@Override
		public boolean method_7674(class_1657 player) {
			return usable;
		}
	}
}
