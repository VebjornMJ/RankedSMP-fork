package net.lusik21556.rankedsmp.gui;

import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_3917;

/**
 * Read-only grid of player heads for admins to inspect/reorganise ranks.
 * Every top-inventory slot rejects normal item handling; clicks are instead
 * forwarded to {@link RankManagementGui#handleClick} which implements the
 * actual select/move/remove logic and re-renders the grid afterwards.
 */
public class RankManagementScreenHandler extends class_1703 {
	private final class_1277 inventory;
	private final int rows;
	private final RankManagementGui gui;

	public RankManagementScreenHandler(int syncId, class_1661 playerInventory, int rows, RankManagementGui gui) {
		super(typeForRows(rows), syncId);
		this.rows = rows;
		this.gui = gui;
		this.inventory = new class_1277(rows * 9);

		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < 9; col++) {
				method_7621(new DisplaySlot(inventory, col + row * 9, 8 + col * 18, 18 + row * 18));
			}
		}
		method_61624(playerInventory, 8, 18 + rows * 18 + 13);
	}

	private static class_3917<?> typeForRows(int rows) {
		return switch (rows) {
			case 1 -> class_3917.field_18664;
			case 2 -> class_3917.field_18665;
			case 3 -> class_3917.field_17326;
			case 4 -> class_3917.field_18666;
			case 5 -> class_3917.field_18667;
			default -> class_3917.field_17327;
		};
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return true;
	}

	@Override
	public class_1799 method_7601(class_1657 player, int slotIndex) {
		return class_1799.field_8037;
	}

	@Override
	public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
		if (actionType == class_1713.field_7790 && slotIndex >= 0 && slotIndex < rows * 9 && player instanceof class_3222 admin) {
			if (button == 0) {
				gui.handleClick(admin, slotIndex, true);
			} else if (button == 1) {
				gui.handleClick(admin, slotIndex, false);
			}
			return;
		}
		super.method_7593(slotIndex, button, actionType, player);
	}

	@Override
	public void method_7595(class_1657 player) {
		super.method_7595(player);
		if (player instanceof class_3222 admin) {
			gui.onClosed(admin);
		}
	}

	public void setSlotDisplay(int index, class_1799 stack) {
		inventory.method_5447(index, stack);
	}

	public int getRows() {
		return rows;
	}

	/** A slot that never accepts insertion or extraction; purely for display. */
	private static class DisplaySlot extends class_1735 {
		DisplaySlot(class_1277 inventory, int index, int x, int y) {
			super(inventory, index, x, y);
		}

		@Override
		public boolean method_7680(class_1799 stack) {
			return false;
		}

		@Override
		public boolean method_7674(class_1657 player) {
			return false;
		}
	}
}
