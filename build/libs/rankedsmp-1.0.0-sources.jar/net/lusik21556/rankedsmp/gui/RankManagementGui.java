package net.lusik21556.rankedsmp.gui;

import net.lusik21556.rankedsmp.data.RankedSaveData;
import net.lusik21556.rankedsmp.rank.RankManager;
import net.lusik21556.rankedsmp.util.Scheduler;
import net.minecraft.class_11560;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;
import net.minecraft.class_9290;
import net.minecraft.class_9296;
import net.minecraft.class_9334;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Port of RankManagementGUI.java: an admin-facing screen showing every
 * currently ranked player as a head, sorted by rank. Left-click selects a
 * player then a destination slot to move them there (swapping with whoever
 * is already there, or shifting the rest of the list when dropped on an
 * empty slot); right-click twice removes a player's rank.
 *
 * Note: the original plugin's "drop on an empty slot to shift" branch was
 * unreachable dead code there (its outer click-guard required the clicked
 * slot to already contain a player head), even though the item lore
 * advertised it. This port fixes that so left-clicking an empty slot while
 * a player is selected behaves as the tooltip describes.
 */
public class RankManagementGui {
	private final RankManager rankManager;
	private final Scheduler scheduler;
	private final Map<UUID, UUID> pendingRemoval = new HashMap<>();
	private final Map<UUID, RankedPlayer> selectedForMove = new HashMap<>();

	public RankManagementGui(RankManager rankManager, Scheduler scheduler) {
		this.rankManager = rankManager;
		this.scheduler = scheduler;
	}

	public void openGui(class_3222 admin) {
		MinecraftServer server = admin.method_51469().method_8503();
		List<RankedPlayer> players = getRankedPlayers(server);
		if (players.isEmpty()) {
			admin.method_7353(class_2561.method_43470("No players are currently ranked!").method_27692(class_124.field_1061), false);
			return;
		}
		int size = Math.min(54, ((players.size() - 1) / 9 + 1) * 9);
		int rows = size / 9;

		admin.method_17355(new class_747(
				(syncId, inv, p) -> new RankManagementScreenHandler(syncId, inv, rows, this),
				class_2561.method_43470("Rank Management").method_27692(class_124.field_1065)
		));

		if (admin.field_7512 instanceof RankManagementScreenHandler handler) {
			populate(server, handler, players, null);
		}
	}

	private void populate(MinecraftServer server, RankManagementScreenHandler handler, List<RankedPlayer> players, UUID selectedUuid) {
		int size = handler.getRows() * 9;
		for (int i = 0; i < size; i++) {
			if (i < players.size()) {
				RankedPlayer rp = players.get(i);
				handler.setSlotDisplay(i, createHead(server, rp, rp.uuid().equals(selectedUuid)));
			} else {
				handler.setSlotDisplay(i, class_1799.field_8037);
			}
		}
	}

	private void refresh(class_3222 admin, UUID selectedUuid) {
		if (admin.field_7512 instanceof RankManagementScreenHandler handler) {
			populate(admin.method_51469().method_8503(), handler, getRankedPlayers(admin.method_51469().method_8503()), selectedUuid);
		}
	}

	private class_1799 createHead(MinecraftServer server, RankedPlayer rp, boolean selected) {
		class_1799 head = new class_1799(class_1802.field_8575);
		head.method_57379(class_9334.field_49617, class_9296.method_73312(rp.uuid()));

		class_2561 name = selected
				? class_2561.method_43470("✓#" + rp.rank() + " - ").method_27692(class_124.field_1060).method_10852(class_2561.method_43470(rp.name()).method_27692(class_124.field_1068))
				: class_2561.method_43470("#" + rp.rank() + " - ").method_27692(class_124.field_1054).method_10852(class_2561.method_43470(rp.name()).method_27692(class_124.field_1068));
		head.method_57379(class_9334.field_49631, name);

		boolean online = server.method_3760().method_14602(rp.uuid()) != null;
		List<class_2561> lore = new ArrayList<>();
		lore.add(class_2561.method_43470(""));
		lore.add(class_2561.method_43470("Rank: ").method_27692(class_124.field_1080).method_10852(class_2561.method_43470("#" + rp.rank()).method_27692(class_124.field_1054)));
		lore.add(class_2561.method_43470("Status: ").method_27692(class_124.field_1080).method_10852(online
				? class_2561.method_43470("Online").method_27692(class_124.field_1060)
				: class_2561.method_43470("Offline").method_27692(class_124.field_1061)));
		lore.add(class_2561.method_43470(""));
		if (selected) {
			lore.add(class_2561.method_43470("Left-Click slot ").method_27692(class_124.field_1060).method_10852(class_2561.method_43470("to move here").method_27692(class_124.field_1080)));
			lore.add(class_2561.method_43470("Right-Click ").method_27692(class_124.field_1054).method_10852(class_2561.method_43470("to cancel").method_27692(class_124.field_1080)));
		} else {
			lore.add(class_2561.method_43470("Left-Click ").method_27692(class_124.field_1065).method_10852(class_2561.method_43470("to select for moving").method_27692(class_124.field_1080)));
			lore.add(class_2561.method_43470("Right-Click ").method_27692(class_124.field_1061).method_10852(class_2561.method_43470("to remove rank").method_27692(class_124.field_1080)));
			lore.add(class_2561.method_43470("Right-Click Again ").method_27692(class_124.field_1079).method_10852(class_2561.method_43470("to confirm").method_27692(class_124.field_1080)));
		}
		head.method_57379(class_9334.field_49632, new class_9290(lore));
		return head;
	}

	private List<RankedPlayer> getRankedPlayers(MinecraftServer server) {
		List<RankedPlayer> players = new ArrayList<>();
		for (Map.Entry<UUID, Integer> entry : RankedSaveData.get(server).getAllRanks().entrySet()) {
			if (entry.getValue() <= 0) {
				continue;
			}
			players.add(new RankedPlayer(entry.getKey(), entry.getValue(), resolveName(server, entry.getKey())));
		}
		players.sort(Comparator.comparingInt(RankedPlayer::rank));
		return players;
	}

	private String resolveName(MinecraftServer server, UUID uuid) {
		class_3222 online = server.method_3760().method_14602(uuid);
		if (online != null) {
			return online.method_7334().name();
		}
		return server.method_73550().comp_4407().method_14512(uuid)
				.map(class_11560::comp_4423)
				.orElse(uuid.toString());
	}

	public void handleClick(class_3222 admin, int slot, boolean isLeftClick) {
		MinecraftServer server = admin.method_51469().method_8503();
		List<RankedPlayer> players = getRankedPlayers(server);
		RankedPlayer clicked = slot < players.size() ? players.get(slot) : null;

		if (isLeftClick) {
			handleLeftClick(admin, server, slot, clicked, players);
		} else {
			handleRightClick(admin, server, clicked);
		}
	}

	private void handleLeftClick(class_3222 admin, MinecraftServer server, int slot, RankedPlayer clicked, List<RankedPlayer> players) {
		RankedPlayer selected = selectedForMove.get(admin.method_5667());
		if (selected == null) {
			if (clicked == null) {
				return;
			}
			selectedForMove.put(admin.method_5667(), clicked);
			admin.method_7353(class_2561.method_43470("Selected " + clicked.name() + " (#" + clicked.rank() + "). Left-click a slot to move, right-click to cancel.").method_27692(class_124.field_1060), false);
			refresh(admin, clicked.uuid());
			return;
		}

		if (clicked != null && clicked.uuid().equals(selected.uuid())) {
			selectedForMove.remove(admin.method_5667());
			admin.method_7353(class_2561.method_43470("Movement cancelled.").method_27692(class_124.field_1054), false);
			refresh(admin, null);
			return;
		}

		int fromRank = selected.rank();
		int toRank = slot + 1;

		if (clicked != null) {
			int targetRank = clicked.rank();
			setRankWithNotice(server, selected.uuid(), targetRank);
			setRankWithNotice(server, clicked.uuid(), fromRank);
			admin.method_7353(class_2561.method_43470("Swapped ranks: " + selected.name() + " (#" + targetRank + ") <-> " + clicked.name() + " (#" + fromRank + ")").method_27692(class_124.field_1060), false);
		} else {
			for (RankedPlayer rp : players) {
				int currentRank = rp.rank();
				if (currentRank == fromRank) {
					continue;
				}
				if (fromRank < toRank) {
					if (currentRank <= fromRank || currentRank > toRank) {
						continue;
					}
					setRankSilent(server, rp.uuid(), currentRank - 1);
				} else {
					if (currentRank < toRank || currentRank >= fromRank) {
						continue;
					}
					setRankSilent(server, rp.uuid(), currentRank + 1);
				}
			}
			setRankWithNotice(server, selected.uuid(), toRank);
			admin.method_7353(class_2561.method_43470("Moved " + selected.name() + " to rank #" + toRank).method_27692(class_124.field_1060), false);
		}

		selectedForMove.remove(admin.method_5667());
		scheduler.runLater(1, () -> refresh(admin, null));
	}

	private void handleRightClick(class_3222 admin, MinecraftServer server, RankedPlayer clicked) {
		if (selectedForMove.containsKey(admin.method_5667())) {
			selectedForMove.remove(admin.method_5667());
			admin.method_7353(class_2561.method_43470("Movement cancelled.").method_27692(class_124.field_1054), false);
			refresh(admin, null);
			return;
		}
		if (clicked == null) {
			return;
		}

		UUID pending = pendingRemoval.get(admin.method_5667());
		if (pending != null && pending.equals(clicked.uuid())) {
			removeRankWithNotice(server, clicked.uuid());
			admin.method_7353(class_2561.method_43470("Removed " + clicked.name() + " from ranked system!").method_27692(class_124.field_1060), false);
			pendingRemoval.remove(admin.method_5667());
			scheduler.runLater(1, () -> refresh(admin, null));
		} else {
			pendingRemoval.put(admin.method_5667(), clicked.uuid());
			admin.method_7353(class_2561.method_43470("Right-click " + clicked.name() + " again to confirm removal!").method_27692(class_124.field_1054), false);
			UUID targetUuid = clicked.uuid();
			scheduler.runLater(60, () -> {
				if (targetUuid.equals(pendingRemoval.get(admin.method_5667()))) {
					pendingRemoval.remove(admin.method_5667());
					admin.method_7353(class_2561.method_43470("Removal cancelled.").method_27692(class_124.field_1061), false);
				}
			});
		}
	}

	private void setRankWithNotice(MinecraftServer server, UUID uuid, int rank) {
		class_3222 online = server.method_3760().method_14602(uuid);
		if (online != null) {
			rankManager.setPlayerRank(online, rank);
			online.method_7353(class_2561.method_43470("Your rank has been changed to #" + rank + " by an admin!").method_27692(class_124.field_1054), false);
		} else {
			rankManager.setOfflineRank(server, uuid, rank);
		}
	}

	private void setRankSilent(MinecraftServer server, UUID uuid, int rank) {
		class_3222 online = server.method_3760().method_14602(uuid);
		if (online != null) {
			rankManager.setPlayerRank(online, rank);
		} else {
			rankManager.setOfflineRank(server, uuid, rank);
		}
	}

	private void removeRankWithNotice(MinecraftServer server, UUID uuid) {
		class_3222 online = server.method_3760().method_14602(uuid);
		if (online != null) {
			rankManager.removePlayerRank(online);
			online.method_7353(class_2561.method_43470("Your rank has been removed by an admin!").method_27692(class_124.field_1054), false);
		} else {
			rankManager.removeOfflineRank(server, uuid);
		}
	}

	public void onClosed(class_3222 admin) {
		pendingRemoval.remove(admin.method_5667());
		selectedForMove.remove(admin.method_5667());
	}

	private record RankedPlayer(UUID uuid, int rank, String name) {
	}
}
