package net.lusik21556.rankedsmp.listener;

import net.fabricmc.fabric.api.entity.event.v1.effect.ServerMobEffectEvents;
import net.lusik21556.rankedsmp.rank.RankManager;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Port of PotionListener.java: beneficial potion effects last longer the
 * higher a player's rank is. Negative effects are left untouched so ranked
 * PvP doesn't accidentally get easier to survive by drinking poison.
 *
 * Fabric API's mob-effect events don't expose a "this was re-applied by the
 * mod itself" cause the way Bukkit's Cause.PLUGIN did, so a small per-player
 * bypass set stands in for that reentrancy guard.
 */
public class PotionEffectHandler {
	private final RankManager rankManager;
	private final Set<UUID> bypass = new HashSet<>();
	private static final Set<class_6880<net.minecraft.class_1291>> NEGATIVE_EFFECTS = Set.of(
			class_1294.field_5909,
			class_1294.field_5906,
			class_1294.field_5901,
			class_1294.field_5916,
			class_1294.field_5919,
			class_1294.field_5903,
			class_1294.field_5911,
			class_1294.field_5899,
			class_1294.field_5920,
			class_1294.field_5902,
			class_1294.field_5908,
			class_1294.field_38092,
			class_1294.field_16595
	);

	public PotionEffectHandler(RankManager rankManager) {
		this.rankManager = rankManager;
	}

	public void register() {
		ServerMobEffectEvents.ALLOW_ADD.register(this::onAllowAdd);
	}

	private boolean onAllowAdd(class_1293 effect, class_1309 entity, net.fabricmc.fabric.api.entity.event.v1.effect.EffectEventContext context) {
		if (!(entity instanceof class_3222 player)) {
			return true;
		}
		UUID uuid = player.method_5667();
		if (bypass.remove(uuid)) {
			return true;
		}
		if (NEGATIVE_EFFECTS.contains(effect.method_5579())) {
			return true;
		}
		int rank = rankManager.getPlayerRank(player);
		if (rank == 0) {
			return true;
		}

		double multiplier = rankManager.getPotionDurationMultiplier(player);
		int newDuration = (int) (effect.method_5584() * multiplier);
		class_1293 extended = new class_1293(effect.method_5579(), newDuration, effect.method_5578(),
				effect.method_5591(), effect.method_5581(), effect.method_5592());

		bypass.add(uuid);
		player.method_6092(extended);
		bypass.remove(uuid);
		return false;
	}
}
