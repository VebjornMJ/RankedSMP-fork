package net.lusik21556.rankedsmp.listener;

import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.lusik21556.rankedsmp.inventory.InventoryManager;
import net.lusik21556.rankedsmp.rank.RankManager;
import net.lusik21556.rankedsmp.util.Scheduler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3222;

/**
 * Wires up the equivalents of PlayerListener.java and part of
 * InventoryListener.java: join/leave display & health refresh, rank-stealing
 * on PvP kills, and post-respawn health re-application.
 */
public class RankedPlayerEvents {
	private final RankManager rankManager;
	private final InventoryManager inventoryManager;
	private final Scheduler scheduler;

	public RankedPlayerEvents(RankManager rankManager, InventoryManager inventoryManager, Scheduler scheduler) {
		this.rankManager = rankManager;
		this.inventoryManager = inventoryManager;
		this.scheduler = scheduler;
	}

	public void register() {
		ServerPlayerEvents.JOIN.register(this::onJoin);
		ServerPlayerEvents.LEAVE.register(this::onLeave);
		ServerPlayerEvents.AFTER_RESPAWN.register(this::onRespawn);
		ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register(this::onKilled);
	}

	private void onJoin(class_3222 player) {
		rankManager.updatePlayerDisplay(player.method_51469().method_8503(), player, rankManager.getPlayerRank(player));
		rankManager.refreshAllOnlinePlayers(player.method_51469().method_8503());
		scheduler.runLater(20, () -> {
			if (player.method_5805()) {
				inventoryManager.loadPlayerInventory(player);
			}
		});
	}

	private void onLeave(class_3222 player) {
		rankManager.removeFromTeam(player.method_51469().method_8503(), player);
		int rank = rankManager.getPlayerRank(player);
		if (!rankManager.hasExtraInventoryAccess(rank)) {
			inventoryManager.clearExtraInventory(player);
		} else {
			inventoryManager.unloadPlayer(player);
		}
	}

	private void onRespawn(class_3222 oldPlayer, class_3222 newPlayer, boolean alive) {
		scheduler.runLater(5, () -> {
			if (newPlayer.method_5805()) {
				rankManager.updatePlayerHealth(newPlayer, rankManager.getPlayerRank(newPlayer));
			}
		});
	}

	private void onKilled(net.minecraft.class_3218 world, class_1297 entity, class_1309 killed, net.minecraft.class_1282 damageSource) {
		if (!(entity instanceof class_3222 killer)) {
			return;
		}
		if (!(killed instanceof class_3222 victim)) {
			return;
		}
		if (killer.method_5667().equals(victim.method_5667())) {
			return;
		}

		int oldRank = rankManager.getPlayerRank(victim);
		boolean hadLoadedExtraInventory = inventoryManager.hasLoadedExtraInventory(victim);
		var deathWorld = victim.method_51469();
		var deathPos = victim.method_73189();

		rankManager.swapRanks(killer, victim);

		int newRank = rankManager.getPlayerRank(victim);
		int oldSlots = rankManager.getSlotsForRank(oldRank);
		int newSlots = rankManager.getSlotsForRank(newRank);
		if (!hadLoadedExtraInventory && newSlots < oldSlots) {
			inventoryManager.handleDeathDropsFallback(victim, deathWorld, deathPos, newRank);
		}
	}
}
