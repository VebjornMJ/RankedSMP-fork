package net.lusik21556.rankedsmp.listener;

import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1324;
import net.minecraft.class_1802;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Port of LocatorListener.java: carrying a Dragon Egg extends how far your
 * waypoint broadcasts and how far you can see other players' waypoints (the
 * vanilla locator-map feature introduced in 1.21.6, which this port always
 * targets, so the original's "1.21.6+ only" version gate is gone).
 *
 * The original polled on inventory click/close/drop/pickup events; Fabric
 * has no generic "inventory changed" event, so this instead polls every 10
 * ticks (0.5s), which is imperceptible for a locator toggle.
 */
public class LocatorHandler {
	private static final double MAX_RANGE = 6.0E7;
	private static final int POLL_INTERVAL_TICKS = 10;

	private final Set<UUID> playersWithEgg = new HashSet<>();
	private int ticksUntilPoll = 0;

	public void register() {
		ServerPlayerEvents.JOIN.register(this::onJoin);
		ServerPlayerEvents.LEAVE.register(player -> playersWithEgg.remove(player.method_5667()));
		ServerTickEvents.END_SERVER_TICK.register(this::onTick);
	}

	private void onJoin(class_3222 player) {
		boolean hasEgg = hasEggInInventory(player);
		setAttributes(player, hasEgg);
		if (hasEgg) {
			playersWithEgg.add(player.method_5667());
		}
	}

	private void onTick(MinecraftServer server) {
		if (++ticksUntilPoll < POLL_INTERVAL_TICKS) {
			return;
		}
		ticksUntilPoll = 0;
		for (class_3222 player : server.method_3760().method_14571()) {
			boolean hasEgg = hasEggInInventory(player);
			boolean hadEgg = playersWithEgg.contains(player.method_5667());
			if (hasEgg == hadEgg) {
				continue;
			}
			if (hasEgg) {
				playersWithEgg.add(player.method_5667());
			} else {
				playersWithEgg.remove(player.method_5667());
			}
			setAttributes(player, hasEgg);
		}
	}

	private boolean hasEggInInventory(class_3222 player) {
		return player.method_31548().method_18861(class_1802.field_8840) > 0;
	}

	private void setAttributes(class_3222 player, boolean hasEgg) {
		class_1324 transmit = player.method_5996(class_5134.field_59672);
		class_1324 receive = player.method_5996(class_5134.field_59673);
		if (transmit != null) {
			transmit.method_6192(MAX_RANGE);
		}
		if (receive != null) {
			receive.method_6192(hasEgg ? MAX_RANGE : 0.0);
		}
	}
}
