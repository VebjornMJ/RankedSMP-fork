package net.lusik21556.rankedsmp.rank;

import net.lusik21556.rankedsmp.RankedSMP;
import net.lusik21556.rankedsmp.config.RankedConfig;
import net.lusik21556.rankedsmp.data.RankedSaveData;
import net.lusik21556.rankedsmp.inventory.InventoryManager;
import net.minecraft.class_124;
import net.minecraft.class_1324;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Port of RankManager.java from the original Paper plugin. Ranks range 1-20;
 * rank 1 is the strongest (20 hearts, biggest inventory, longest potions,
 * fastest XP), rank 20 the weakest (10.5 hearts). Unranked players (rank 0)
 * play vanilla.
 */
public class RankManager {
	private final RankedConfig config;
	private InventoryManager inventoryManager;

	public RankManager(RankedConfig config) {
		this.config = config;
	}

	public void setInventoryManager(InventoryManager inventoryManager) {
		this.inventoryManager = inventoryManager;
	}

	public int getPlayerRank(class_3222 player) {
		return RankedSaveData.get(player.method_51469().method_8503()).getRank(player.method_5667());
	}

	public void setPlayerRank(class_3222 player, int rank) {
		MinecraftServer server = player.method_51469().method_8503();
		RankedSaveData data = RankedSaveData.get(server);
		int oldRank = data.getRank(player.method_5667());
		data.setRank(player.method_5667(), rank);
		updatePlayerDisplay(server, player, rank);
		updatePlayerHealth(player, rank);
		if (inventoryManager != null) {
			inventoryManager.updateExtraInventory(player, oldRank, rank);
		}
	}

	public void removePlayerRank(class_3222 player) {
		MinecraftServer server = player.method_51469().method_8503();
		RankedSaveData data = RankedSaveData.get(server);
		int oldRank = data.getRank(player.method_5667());
		data.removeRank(player.method_5667());
		updatePlayerDisplay(server, player, 0);
		resetPlayerHealth(player);
		if (inventoryManager != null) {
			inventoryManager.updateExtraInventory(player, oldRank, 0);
		}
	}

	/** Sets a rank for a UUID that may not currently be online. */
	public void setOfflineRank(MinecraftServer server, UUID uuid, int rank) {
		RankedSaveData.get(server).setRank(uuid, rank);
	}

	public void removeOfflineRank(MinecraftServer server, UUID uuid) {
		RankedSaveData.get(server).removeRank(uuid);
	}

	public void updatePlayerDisplay(MinecraftServer server, class_3222 player, int rank) {
		updateScoreboardTeam(server, player, rank);
	}

	private void updateScoreboardTeam(MinecraftServer server, class_3222 player, int rank) {
		class_269 scoreboard = server.method_3845();
		removeFromTeam(server, player);

		String teamName;
		class_2561 prefix;
		if (rank > 0) {
			teamName = String.format("rank_%02d", rank);
			prefix = class_2561.method_43470("[#" + rank + "] ").method_27692(class_124.field_1054);
		} else {
			teamName = "rank_99_unranked";
			prefix = class_2561.method_43470("[").method_27692(class_124.field_1054)
					.method_10852(class_2561.method_43470("UNRANKED").method_27692(class_124.field_1063))
					.method_10852(class_2561.method_43470("] ").method_27692(class_124.field_1054));
		}

		class_268 team = scoreboard.method_1153(teamName);
		if (team == null) {
			team = scoreboard.method_1171(teamName);
		}
		team.method_1138(prefix);
		team.method_1143(false);
		scoreboard.method_1172(player.method_7334().name(), team);
	}

	public void removeFromTeam(MinecraftServer server, class_3222 player) {
		class_269 scoreboard = server.method_3845();
		String name = player.method_7334().name();
		class_268 team = scoreboard.method_1164(name);
		if (team != null) {
			scoreboard.method_1157(name, team);
		}
	}

	/** Re-applies display/health/rank state for every currently online player. Used on join and /rankedsmp reload. */
	public void refreshAllOnlinePlayers(MinecraftServer server) {
		for (class_3222 player : server.method_3760().method_14571()) {
			int rank = getPlayerRank(player);
			updatePlayerDisplay(server, player, rank);
			updatePlayerHealth(player, rank);
		}
	}

	public void startRankedSMP(MinecraftServer server) {
		List<class_3222> onlinePlayers = new ArrayList<>(server.method_3760().method_14571());
		if (onlinePlayers.isEmpty()) {
			return;
		}

		RankedSaveData data = RankedSaveData.get(server);
		for (UUID uuid : new ArrayList<>(data.getAllRanks().keySet())) {
			data.removeRank(uuid);
		}
		for (class_3222 player : onlinePlayers) {
			removeFromTeam(server, player);
		}

		int maxPlayers = Math.min(20, onlinePlayers.size());
		List<Integer> availableRanks = new ArrayList<>();
		for (int i = 1; i <= maxPlayers; i++) {
			availableRanks.add(i);
		}
		Collections.shuffle(availableRanks);

		for (int i = 0; i < maxPlayers; i++) {
			class_3222 player = onlinePlayers.get(i);
			int rank = availableRanks.get(i);
			setPlayerRank(player, rank);
			player.method_7353(class_2561.method_43470("You have been assigned rank ")
					.method_27692(class_124.field_1060)
					.method_10852(class_2561.method_43470("#" + rank).method_27692(class_124.field_1054))
					.method_10852(class_2561.method_43470("!").method_27692(class_124.field_1060)), false);
		}

		int unranked = onlinePlayers.size() - maxPlayers;
		if (unranked > 0) {
			for (int i = maxPlayers; i < onlinePlayers.size(); i++) {
				onlinePlayers.get(i).method_7353(class_2561.method_43470("No available Ranks! You are unranked.").method_27692(class_124.field_1061), false);
			}
			server.method_3760().method_43514(class_2561.method_43470("Ranked SMP has begun! " + maxPlayers + " players ranked, " + unranked + " unranked.").method_27692(class_124.field_1065), false);
		} else {
			server.method_3760().method_43514(class_2561.method_43470("Ranked SMP has begun! Ranks have been assigned.").method_27692(class_124.field_1065), false);
		}
	}

	public void swapRanks(class_3222 killer, class_3222 victim) {
		if (!config.isRankStealingEnabled()) {
			return;
		}
		int killerRank = getPlayerRank(killer);
		int victimRank = getPlayerRank(victim);
		if (victimRank == 0) {
			return;
		}
		if (killerRank == 0 || killerRank > victimRank) {
			setPlayerRank(killer, victimRank);
			if (killerRank > 0) {
				setPlayerRank(victim, killerRank);
			} else {
				removePlayerRank(victim);
			}

			killer.method_7353(class_2561.method_43470("You stole " + victim.method_7334().name() + "'s rank! You are now ")
					.method_27692(class_124.field_1065)
					.method_10852(class_2561.method_43470("#" + victimRank).method_27692(class_124.field_1054)), false);
			if (killerRank > 0) {
				victim.method_7353(class_2561.method_43470("Your rank was stolen by " + killer.method_7334().name() + ". You are now ")
						.method_27692(class_124.field_1061)
						.method_10852(class_2561.method_43470("#" + killerRank).method_27692(class_124.field_1054)), false);
			} else {
				victim.method_7353(class_2561.method_43470("Your rank was stolen by " + killer.method_7334().name() + ". You are now ")
						.method_27692(class_124.field_1061)
						.method_10852(class_2561.method_43470("UNRANKED").method_27692(class_124.field_1063)), false);
			}
		}
	}

	public void updatePlayerHealth(class_3222 player, int rank) {
		if (player.method_29504()) {
			return;
		}
		if (rank == 0) {
			resetPlayerHealth(player);
			return;
		}
		double hearts = 10.5 + (20 - rank) * 0.5;
		double maxHealth = hearts * 2.0;
		class_1324 attribute = player.method_5996(class_5134.field_23716);
		if (attribute != null) {
			attribute.method_6192(maxHealth);
		}
		player.method_6033((float) Math.min(player.method_6032(), maxHealth));
	}

	public void resetPlayerHealth(class_3222 player) {
		if (player.method_29504()) {
			return;
		}
		class_1324 attribute = player.method_5996(class_5134.field_23716);
		if (attribute != null) {
			attribute.method_6192(20.0);
		}
		player.method_6033(20.0f);
	}

	public boolean isRankTaken(MinecraftServer server, int rank) {
		return RankedSaveData.get(server).isRankTaken(rank);
	}

	public UUID getPlayerWithRank(MinecraftServer server, int rank) {
		return RankedSaveData.get(server).getPlayerWithRank(rank);
	}

	public double getPotionDurationMultiplier(class_3222 player) {
		int rank = getPlayerRank(player);
		if (rank == 0) {
			return 1.0;
		}
		double minMultiplier = 1.05;
		double maxMultiplier = 2.0;
		return minMultiplier + (21 - rank) / 20.0 * (maxMultiplier - minMultiplier);
	}

	public double getXPMultiplier(class_3222 player) {
		int rank = getPlayerRank(player);
		if (rank == 0) {
			return 1.0;
		}
		double minMultiplier = 1.1;
		double maxMultiplier = 3.0;
		return minMultiplier + (21 - rank) / 20.0 * (maxMultiplier - minMultiplier);
	}

	public int getExtraInventorySlots(class_3222 player) {
		return getSlotsForRank(getPlayerRank(player));
	}

	public int getSlotsForRank(int rank) {
		if (rank == 0 || rank > 10) {
			return 0;
		}
		if (rank <= 2) {
			return 54;
		}
		return 65 - rank * 5;
	}

	public boolean hasExtraInventoryAccess(int rank) {
		return rank > 0 && rank <= 10;
	}
}
